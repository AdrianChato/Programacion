package trabajoentorno;

import java.util.Scanner;

public class ejercicio1 {

	public static void main(String[] args) {
		 int numero = 4;
		 int[] array = new int[23];
		 numero=8-20;
		 numero=14+numero-2;
		 int numero2 = -18;
		 for (int i = 0; i < 27; i++) {
		 int numero3=27+14;
		 numero2=numero2;
		 }
		 for (int i = 0; i < 4; i++) {
		 numero2=1*7+numero2;
		 }
		 for (int i = 0; i < 38; i++) {
		 int numero3=246;
		 numero=-3+numero+4;
		 }
		 for (int i = 0; i < array.length; i++) {
		 array[i]=numero-26;
		 }
		 System.out.println("Fin");
	}
}
