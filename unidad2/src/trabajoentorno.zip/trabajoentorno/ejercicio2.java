package trabajoentorno;

public class ejercicio2 {
	
	 public static void main(String[] args) {
		 int numero = 4;
		 int[] array = new int[23];
		 numero=8-20;
		 numero=14+numero-2;
		 int numero2 = -18;
		 for (int i = 0; i < 27; i++) {
		 numero2=numero2+4*2;
		 }
		 for (int i = 0; i < 8; i++) {
		 int numero3=296;
		 numero=-13+numero+7;
		 }
		 for (int i = 0; i < array.length; i++) {
		 array[i]=numero-2;
		 }
		 System.out.println("Fin");
		 }
		}
