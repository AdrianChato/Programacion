package trabajoentorno;

public class ejercicio5 {
	
	 public static void main(String[] args) {
		 String palabra = "adrianchatopapi";
		 int longitud = palabra.length();
		 System.out.println("Longitud de la palabra: " + longitud);
		 }
		}

