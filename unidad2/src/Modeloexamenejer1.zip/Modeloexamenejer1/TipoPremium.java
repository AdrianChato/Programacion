package Modeloexamenejer1;

public enum TipoPremium {
PREMIUM,PREMIUM_VIP
}
