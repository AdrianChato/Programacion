package Modeloexamenejer1;

public class GuzmanitosException extends Exception{

	public GuzmanitosException(String mensaje) {
		super(mensaje);
	}

	
}
