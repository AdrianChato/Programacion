package Modeloexamenejer2;

public enum Valores {
LOW_COST,NORMAL,EXPRESS
}
