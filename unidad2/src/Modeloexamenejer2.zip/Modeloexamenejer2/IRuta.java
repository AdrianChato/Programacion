package Modeloexamenejer2;

public interface IRuta {

	public double getCoste();
	public void getTipoRuta();
}
