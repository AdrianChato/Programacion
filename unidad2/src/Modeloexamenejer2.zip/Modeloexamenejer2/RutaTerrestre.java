package Modeloexamenejer2;

public class RutaTerrestre extends RutaBase{

	private boolean siesCarreterra;
	private double costecienkms;
	
	public RutaTerrestre(int id, String ciudadorigen, String ciudaddestino, int distancia, boolean siesCarreterra) {
		super(id, ciudadorigen, ciudaddestino, distancia);
		this.siesCarreterra = siesCarreterra;
		this.costecienkms = 0.65;
	}

	@Override
	public double getCoste() {
		return getDistancia() * this.costecienkms;
	}

	@Override
	public void getTipoRuta() {
		if (siesCarreterra == true) {
			System.out.println("(RutaTerrestre) +  - carretera");
		} else {
			System.out.println("(RutaTerrestre) +  - tren");
		}
	}
	
	
	
	
}
